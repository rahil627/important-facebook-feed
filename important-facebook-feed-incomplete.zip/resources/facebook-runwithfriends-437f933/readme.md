Sample Canvas Application
-------------------------

Run with Friends is a sample web based **[Facebook Canvas
Application](http://developers.facebook.com/docs/guides/canvas/)**. Visit
**[the guide to the
sample](http://developers.facebook.com/docs/samples/canvas)** for additional
documentation, and
**[http://apps.facebook.com/runwithfriends/](http://apps.facebook.com/runwithfriends/)**
to see the running application.
